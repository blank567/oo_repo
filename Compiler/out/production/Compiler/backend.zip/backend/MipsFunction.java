package backend;

public class MipsFunction {
    private int offsetOfStack;
}
