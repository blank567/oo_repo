package backend.MipsInstruction;

import backend.Register;

public class Jr implements MipsInstruction {
    private Register target;

    public Jr(Register target) {
        this.target = target;
    }

    public String toString() {
        return "jr " + target + "\n";
    }
}
