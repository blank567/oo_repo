package frontend.SyntaxTree;

public class Number {
    private int num;

    public Number(int num) {
        this.num = num;
    }

}
