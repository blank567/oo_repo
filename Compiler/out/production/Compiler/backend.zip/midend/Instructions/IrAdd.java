package midend.Instructions;

import backend.MipsInstruction.Addi;
import backend.MipsInstruction.Addu;
import backend.Register;
import midend.Function;
import midend.User;
import midend.Value;

import static midend.Module.module;
import static backend.Register.allocTReg;
import static backend.Register.getByOffset;
import static backend.Register.isGlobalReg;
import static backend.Register.isTempReg;
import static backend.Register.freeTReg;

public class IrAdd extends User {

    public IrAdd(String value, Value op1, Value op2) {
        super(value, 0);
        super.addOperand(op1);
        super.addOperand(op2);
    }

    public String toString() {
        return super.value + " = add i32 " + operands.get(0).value + ", " + operands.get(1).value + "\n";
    }

    public String toMips() {
        Value op1 = operands.get(0);
        Value op2 = operands.get(1);
        if(op1.isNumber() || op2.isNumber()) {
            if(op1.isNumber()) {
                if(op2.getIsInReg()) {
                    Register reg = allocTReg();
                    Addi addi = new Addi(reg, op2.getRegister(), Integer.parseInt(op1.value));
                    this.setRegister(reg);
                    return addi.toString();
                } else {
                    Register reg = op2.getRegister();
                    Addi addi = new Addi(reg, reg, Integer.parseInt(op1.value));
                    this.setRegister(reg);
                    return addi.toString();
                }
            } else if(op2.isNumber()) {
                if(op1.getIsInReg()) {
                    Register reg = allocTReg();
                    Addi addi = new Addi(reg, op1.getRegister(), Integer.parseInt(op2.value));
                    this.setRegister(reg);
                    return addi.toString();
                } else {
                    Register reg = op1.getRegister();
                    Addi addi = new Addi(reg, reg, Integer.parseInt(op2.value));
                    this.setRegister(reg);
                    return addi.toString();
                }
            } else {
                System.out.println("Error: add operation with two non-number values");
            }
        } else {
            Register reg1 = op1.getRegister();
            Register reg2 = op2.getRegister();
            if(op1.getIsInReg()) {
                if(op2.getIsInReg()) {
                    Register reg = allocTReg();
                    Addu addu = new Addu(reg, reg1, reg2);
                    this.setRegister(reg);
                    return addu.toString();
                } else {
                    Addu addu = new Addu(reg2, reg1, reg2);
                    this.setRegister(reg2);
                    return addu.toString();
                }
            } else if(op2.getIsInReg()) {
                Addu addu = new Addu(reg1, reg1, reg2);
                this.setRegister(reg1);
                return addu.toString();
            } else {
                Addu addu = new Addu(reg1, reg1, reg2);
                this.setRegister(reg1);
                freeTReg(reg2);
                return addu.toString();
            }
        }
        return null;
    }
}
