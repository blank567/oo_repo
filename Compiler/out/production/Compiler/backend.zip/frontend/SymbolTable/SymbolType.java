package frontend.SymbolTable;

public enum SymbolType {
    ConstChar,
    Char,
    VoidFunc,
    ConstInt,
    Int,
    CharFunc,
    ConstCharArray,
    CharArray,
    IntFunc,
    ConstIntArray,
    IntArray
}
