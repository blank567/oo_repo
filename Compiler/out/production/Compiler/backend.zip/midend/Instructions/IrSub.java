package midend.Instructions;

import backend.MipsInstruction.Addi;
import backend.MipsInstruction.Li;
import backend.MipsInstruction.Subu;
import backend.Register;
import midend.User;
import midend.Value;

import static backend.Register.allocTReg;
import static backend.Register.freeTReg;

public class IrSub extends User {

    public IrSub(String value, Value op1, Value op2) {
        super(value, 0);
        super.addOperand(op1);
        super.addOperand(op2);
    }

    public String toString() {
        return super.value + " = sub i32 " + operands.get(0).value + ", " + operands.get(1).value + "\n";
    }

    public String toMips() {
        StringBuilder sb = new StringBuilder();
        Value op1 = operands.get(0);
        Value op2 = operands.get(1);
        if(op1.isNumber() || op2.isNumber()) {
            if(op1.isNumber()) {
                if(op2.getIsInReg()) {
                    Register reg = allocTReg();
                    Li li = new Li(reg, Integer.parseInt(op1.value));
                    sb.append(li);
                    Subu subu = new Subu(reg, reg, op2.getRegister());
                    this.setRegister(reg);
                    return sb.append(subu).toString();
                } else {
                    Register tmp = allocTReg();
                    Li li = new Li(tmp, Integer.parseInt(op1.value));
                    sb.append(li);
                    Register reg = op2.getRegister();
                    Subu subu = new Subu(reg, tmp, reg);
                    this.setRegister(reg);
                    assert tmp != null;
                    freeTReg(tmp);
                    return sb.append(subu).toString();
                }
            } else if(op2.isNumber()) {
                if(op1.getIsInReg()) {
                    Register reg = allocTReg();
                    Addi addi = new Addi(reg, op1.getRegister(), -Integer.parseInt(op2.value));
                    this.setRegister(reg);
                    return addi.toString();
                } else {
                    Register reg = op1.getRegister();
                    Addi addi = new Addi(reg, reg, -Integer.parseInt(op2.value));
                    this.setRegister(reg);
                    return addi.toString();
                }
            } else {
                System.out.println("Error: add operation with two non-number values");
            }
        } else {
            Register reg1 = op1.getRegister();
            Register reg2 = op2.getRegister();
            if(op1.getIsInReg()) {
                if(op2.getIsInReg()) {
                    Register reg = allocTReg();
                    Subu subu = new Subu(reg, reg1, reg2);
                    this.setRegister(reg);
                    return subu.toString();
                } else {
                    Subu subu = new Subu(reg2, reg1, reg2);
                    this.setRegister(reg2);
                    return subu.toString();
                }
            } else if(op2.getIsInReg()) {
                Subu subu = new Subu(reg1, reg1, reg2);
                this.setRegister(reg1);
                return subu.toString();
            } else {
                Subu subu = new Subu(reg1, reg1, reg2);
                this.setRegister(reg1);
                freeTReg(reg2);
                return subu.toString();
            }
        }
        return null;
    }
}
