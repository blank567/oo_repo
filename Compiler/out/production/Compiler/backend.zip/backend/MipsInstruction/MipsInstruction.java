package backend.MipsInstruction;

public interface MipsInstruction {
}
